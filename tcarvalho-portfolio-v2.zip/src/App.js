import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import CaseBV from './pages/CaseBV';
import CaseMAAR from './pages/CaseMAAR';
import CaseComingSoon from './pages/CaseComingSoon';
import Sobre from './pages/Sobre';
import Contato from './pages/Contato';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/case/visao360" element={<CaseBV />} />
        <Route path="/case/petrobras" element={<CaseMAAR />} />
        <Route path="/case/realestate" element={<CaseComingSoon title="Transformação Digital de Gestão de Imóveis" subtitle="Pátria Investments · Salesforce · Service Design" prev="/case/petrobras" prevTitle="Sistema de Avaliação de Mérito" next="/case/maquininha" nextTitle="Área de Ajuda na Maquininha" />} />
        <Route path="/case/maquininha" element={<CaseComingSoon title="Área de Ajuda na Maquininha" subtitle="Cielo · UI/UX · Design Sprint" prev="/case/realestate" prevTitle="Transformação Digital de Imóveis" next="/" nextTitle="Voltar para home" />} />
        <Route path="/sobre" element={<Sobre />} />
        <Route path="/contato" element={<Contato />} />
      </Routes>
    </BrowserRouter>
  );
}
